from time import time


def get_timestamp() -> int:
    return int(time())
